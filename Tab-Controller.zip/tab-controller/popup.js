"use strict";
const $ = (id) => document.getElementById(id);
const labels = {
  "go-left": "shortcut-left",
  "go-right": "shortcut-right",
  "go-previous": "shortcut-previous"
};

function formatShortcut(shortcut) {
  return shortcut.replaceAll("MacCtrl", "Ctrl").replaceAll("Ctrl", "Ctrl")
    .replaceAll("Alt", "Alt").replaceAll("+", " + ")
    .replaceAll("Left", "←").replaceAll("Right", "→");
}

async function refreshShortcuts() {
  try {
    const commands = await chrome.commands.getAll();
    let missing = false;
    for (const command of commands) {
      const elementId = labels[command.name];
      if (!elementId) continue;
      const assigned = Boolean(command.shortcut);
      $(elementId).textContent = assigned ? formatShortcut(command.shortcut) : "Not assigned";
      if (!assigned) missing = true;
    }
    $("shortcut-warning").hidden = !missing;
  } catch (error) {
    $("shortcut-warning").hidden = false;
  }
}

async function refreshStatus() {
  try {
    const status = await chrome.runtime.sendMessage({ type: "status" });
    if (!status?.ok) {
      $("feedback").textContent = status?.error || "Could not retrieve tab history.";
      return;
    }
    $("current-title").textContent = status.current?.title || "Current tab";
    $("current-title").title = status.current?.url || "";
    $("previous-title").textContent = status.previous?.title || "No previous tab yet";
    $("previous-title").title = status.previous?.url || "";
  } catch {
    $("feedback").textContent = "Tab history is temporarily unavailable.";
  }
}

async function navigate(command) {
  const buttons = [...document.querySelectorAll("[data-command]")];
  buttons.forEach((button) => { button.disabled = true; });
  $("feedback").textContent = "";
  try {
    const result = await chrome.runtime.sendMessage({ type: "navigate", action: command });
    if (!result?.ok) $("feedback").textContent = result?.error || "Could not switch tabs.";
    await refreshStatus();
  } catch {
    $("feedback").textContent = "Could not switch tabs.";
  } finally {
    buttons.forEach((button) => { button.disabled = false; });
  }
}

document.querySelectorAll("[data-command]").forEach((button) => {
  button.addEventListener("click", () => { void navigate(button.dataset.command); });
});
$("refresh").addEventListener("click", () => { void refreshStatus(); void refreshShortcuts(); });
$("open-shortcuts").addEventListener("click", () => {
  void chrome.tabs.create({ url: "chrome://extensions/shortcuts" });
});

void refreshStatus();
void refreshShortcuts();
