# Northline Market — Product Recommendation Agent

## 1. What problem are we solving?

Northline Market has **1,000 products** and five different customer types (personas).
Our job is to recommend the **best 5 products for each persona**.

The important part is that we do not simply sort products by one score. Our agent:

1. checks every **must-have rule** first;
2. removes products that fail those rules;
3. applies the **official scoring formula** given in the dataset;
4. checks whether that formula is ignoring any customer preference;
5. explains why each product was recommended;
6. tests edge cases so the system does not make unsafe recommendations.

## 2. What data did we use?

- `product_catalog.csv` — 1,000 products such as laptops, headphones, monitors and chairs.
- `customer_personas.json` — five customer personas, their must-have rules, preferences and the official scoring formula.
- `DATA_DICT.md` — meaning of every field in the dataset.

Examples of must-have rules:

- maximum budget;
- minimum battery life;
- minimum RAM;
- minimum rating;
- minimum monitor size;
- required tags such as `wireless`, `anc` or `ergonomic`.

If a product fails even one must-have rule, **we do not recommend it**.

## 3. Official scoring formula

We first reproduce the exact formula given in the persona file:

```text
score = 0.40 × price_fit + 0.30 × rating_norm + 0.30 × tag_overlap
```

Where:

- `price_fit` rewards products that are comfortably inside the customer's budget;
- `rating_norm` rewards higher-rated products;
- `tag_overlap` rewards products that match the customer's preferred tags;
- products are ranked by score;
- ties are broken by higher rating, then lower price;
- only products that pass every must-have rule are allowed into the ranking.

## 4. Important finding

The supplied formula is useful, but it does **not read every preference written for the personas**.

It uses preferred tags, price and rating, but it does not directly use some other written preferences such as:

- preferred laptop/headphone weight;
- preferred battery life;
- persona-specific preferred rating thresholds.

Across the five personas we produced 25 official recommendation positions (5 per persona).
**7 of those 25 positions (28%) missed at least one written non-tag preference that the formula does not check.**

### Simple example

The student persona says:

- laptop only;
- price at or below $600;
- battery at least 12 hours;
- rating at least 3.8;
- and **prefers weight below 1.5 kg**.

The official formula checks budget, rating and preferred tags, but it does not use the 1.5 kg weight preference in the score.
So a heavier laptop can still rank near the top.

This is why our solution has a **critic step** after the normal ranking.

## 5. Results

### Best official recommendation for each persona

| Persona | Eligible products after must-have rules | #1 recommendation | Why it fits |
|---|---:|---|---|
| Leah the undergrad | 16 | **Northline Pico 14** (`SKU-0001`) | preferred tags matched 2/2 (light, student); weight 1.28 kg meets preference < 1.5 kg |
| Marcus in Northline IT | 48 | **Reef 13 9** (`SKU-0223`) | preferred tags matched 2/2 (business, docking); battery 17.3 h meets preference > 10 h |
| Amina the consultant on the road | 10 | **Quay Quiet 2** (`SKU-0011`) | preferred tags matched 2/2 (folding, travel); weight 0.24 kg meets preference < 0.3 kg |
| Chris in brand design | 49 | **View 32 17** (`SKU-0092`) | preferred tags matched 2/2 (color, ips); rating 4.8 meets preference > 4.4 |
| Priya the remote lead | 22 | **Seat 37** (`SKU-0250`) | preferred tags matched 1/2 (lumbar); rating 4.5 meets preference > 4.3 |

### Full official Top 5

#### Leah the undergrad

1. **Northline Pico 14** (`SKU-0001`) — $479.00, rating 4.3, score 0.5407. preferred tags matched 2/2 (light, student); weight 1.28 kg meets preference < 1.5 kg. It ranks above the next item mainly because of stronger preferred-tag overlap, weaker rating.
2. **Reef 13 9** (`SKU-0223`) — $385.12, rating 4.7, score 0.5333. preferred tags matched 1/2 (light); weight 2.11 kg misses preference < 1.5 kg. It ranks above the next item mainly because of stronger price fit, weaker rating.
3. **Drift 14 6** (`SKU-0229`) — $431.22, rating 4.8, score 0.5225. preferred tags matched 1/2 (light); weight 1.91 kg misses preference < 1.5 kg. It ranks above the next item mainly because of stronger price fit, weaker rating.
4. **CoveBook 5** (`SKU-0465`) — $493.90, rating 4.9, score 0.5007. preferred tags matched 1/2 (light); weight 2.26 kg misses preference < 1.5 kg. It ranks above the next item mainly because of weaker preferred-tag overlap, stronger rating.
5. **Alder AirWrite** (`SKU-0003`) — $599.00, rating 4.4, score 0.4807. preferred tags matched 2/2 (light, student); weight 1.19 kg meets preference < 1.5 kg.

#### Marcus in Northline IT

1. **Reef 13 9** (`SKU-0223`) — $385.12, rating 4.7, score 0.8700. preferred tags matched 2/2 (business, docking); battery 17.3 h meets preference > 10 h. It ranks above the next item mainly because of higher aggregate score after the published tie-breaks.
2. **Reef 13 4** (`SKU-0361`) — $463.84, rating 4.7, score 0.8557. preferred tags matched 2/2 (business, docking); battery 12.6 h meets preference > 10 h. It ranks above the next item mainly because of stronger rating, stronger price fit.
3. **Shift 15 1** (`SKU-0124`) — $727.75, rating 4.3, score 0.7277. preferred tags matched 2/2 (business, docking); battery 15.4 h meets preference > 10 h. It ranks above the next item mainly because of higher aggregate score after the published tie-breaks.
4. **CoveBook 1** (`SKU-0882`) — $831.00, rating 4.3, score 0.7089. preferred tags matched 2/2 (business, docking); battery 17.9 h meets preference > 10 h. It ranks above the next item mainly because of stronger preferred-tag overlap, weaker price fit.
5. **Shift 14 1** (`SKU-0794`) — $370.67, rating 4.5, score 0.6826. preferred tags matched 1/2 (docking); battery 11.2 h meets preference > 10 h.

#### Amina the consultant on the road

1. **Quay Quiet 2** (`SKU-0011`) — $229.00, rating 4.5, score 0.6383. preferred tags matched 2/2 (folding, travel); weight 0.24 kg meets preference < 0.3 kg. It ranks above the next item mainly because of stronger preferred-tag overlap, weaker price fit.
2. **Audio 368** (`SKU-0742`) — $58.67, rating 4.1, score 0.6029. preferred tags matched 1/2 (folding); weight 0.29 kg meets preference < 0.3 kg. It ranks above the next item mainly because of stronger price fit, weaker rating.
3. **Audio 194** (`SKU-0073`) — $251.31, rating 4.9, score 0.5428. preferred tags matched 1/2 (travel); weight 0.15 kg meets preference < 0.3 kg. It ranks above the next item mainly because of stronger rating, weaker price fit.
4. **CabinPulse** (`SKU-0012`) — $179.00, rating 4.2, score 0.4854. preferred tags matched 1/2 (travel); weight 0.22 kg meets preference < 0.3 kg. It ranks above the next item mainly because of stronger rating, stronger price fit.
5. **Audio 825** (`SKU-0067`) — $213.38, rating 4.0, score 0.4061. preferred tags matched 1/2 (travel); weight 0.35 kg misses preference < 0.3 kg.

#### Chris in brand design

1. **View 32 17** (`SKU-0092`) — $189.07, rating 4.8, score 0.8760. preferred tags matched 2/2 (color, ips); rating 4.8 meets preference > 4.4. It ranks above the next item mainly because of stronger price fit.
2. **View 27 18** (`SKU-0900`) — $483.73, rating 4.8, score 0.7450. preferred tags matched 2/2 (color, ips); rating 4.8 meets preference > 4.4. It ranks above the next item mainly because of stronger preferred-tag overlap, weaker price fit.
3. **View 27 19** (`SKU-0741`) — $155.56, rating 4.8, score 0.7409. preferred tags matched 1/2 (color); rating 4.8 meets preference > 4.4. It ranks above the next item mainly because of weaker preferred-tag overlap, stronger rating.
4. **Lumen 27 IPS** (`SKU-0016`) — $329.00, rating 4.3, score 0.7138. preferred tags matched 2/2 (color, ips); rating 4.3 misses preference > 4.4. It ranks above the next item mainly because of stronger rating, weaker price fit.
5. **View 24 12** (`SKU-0870`) — $249.68, rating 4.1, score 0.7090. preferred tags matched 2/2 (color, ips); rating 4.1 misses preference > 4.4.

#### Priya the remote lead

1. **Seat 37** (`SKU-0250`) — $107.80, rating 4.5, score 0.6542. preferred tags matched 1/2 (lumbar); rating 4.5 meets preference > 4.3. It ranks above the next item mainly because of stronger rating.
2. **Seat 79** (`SKU-0829`) — $117.01, rating 4.4, score 0.6260. preferred tags matched 1/2 (lumbar); rating 4.4 meets preference > 4.3. It ranks above the next item mainly because of weaker preferred-tag overlap, stronger price fit.
3. **Alder Mesh Desk** (`SKU-0021`) — $289.00, rating 4.4, score 0.6231. preferred tags matched 2/2 (lumbar, mesh); rating 4.4 meets preference > 4.3. It ranks above the next item mainly because of stronger preferred-tag overlap, weaker price fit.
4. **Seat 82** (`SKU-0869`) — $152.59, rating 4.5, score 0.6144. preferred tags matched 1/2 (lumbar); rating 4.5 meets preference > 4.3. It ranks above the next item mainly because of stronger rating, weaker price fit.
5. **Seat 95** (`SKU-0097`) — $108.64, rating 4.3, score 0.6134. preferred tags matched 1/2 (mesh); rating 4.3 misses preference > 4.3.

## 6. Why this is Agentic AI

Our solution follows a loop instead of doing one calculation and stopping:

```text
READ DATA
   ↓
CHECK MUST-HAVE RULES
   ↓
RANK WITH OFFICIAL FORMULA
   ↓
CHECK THE RESULT
   ↓
FIND MISSING / IGNORED PREFERENCES
   ↓
TEST EDGE CASES
   ↓
EXPLAIN OR ESCALATE
```

The important idea is that the system **checks its own result** instead of blindly trusting the first ranking.

## 7. How we improved the decision process

We did **not silently replace** the official formula.

That would be dangerous because changing preference weights is a business decision.
Instead, we keep the official ranking as the main result and run a second **sensitivity check**:

- every written preference is allowed to influence the comparison;
- we show when rankings move;
- a merchandiser can decide whether the official formula should be changed.

This gives us both **auditability** and **better reasoning**.

## 8. Edge-case tests

### Test A — Formula-gaming product

We created a fake student laptop that:

- costs only $50;
- has 12 hours battery;
- has the preferred `student` and `light` tags;
- but weighs **4.0 kg**.

It passes the student's must-have rules and receives a strong official score even though it badly misses the written weight preference.
This proves why the critic step is useful.

### Test B — Impossible customer

We created a customer whose budget is so low that no product can pass.

Correct result: **0 recommendations**.

The agent does not break a must-have rule just to fill five positions.

## 9. What should happen in a real system?

Before using this on a live store, we would add:

- version control for persona rules and scoring rules;
- automatic schema checks when the weekly catalog changes;
- a hard-rule safety check with a target violation rate of **0%**;
- logging of every product removed and the reason;
- logging of every score component;
- human approval before changing the scoring formula;
- monitoring of conversion, returns, no-result rate and ranking changes;
- rollback if a new scoring version performs badly.

## 10. When should we stop or roll back the agent?

We would stop or roll back the system if:

- any recommended product breaks a must-have rule;
- required catalog fields disappear or change type;
- conversion drops materially;
- return/refund rate rises materially;
- rankings change sharply without an approved rule change.

## 11. How to run

```text
python recommender.py
```

Generated output:

- `results.json`
- `ANALYSIS_REPORT.md`

## 12. Final takeaway

The solution does more than recommend products.
It **follows the business rules, explains its choices, checks its own ranking, finds weaknesses in the given formula and knows when a human should decide**.