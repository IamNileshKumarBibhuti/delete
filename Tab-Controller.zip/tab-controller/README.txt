TAB CONTROLLER — version 1.0.0
==================================
A standalone Chrome extension for switching tabs quickly.

KEYBOARD SHORTCUTS (Windows/Linux):
- Ctrl + Left Arrow   : move one tab to the left
- Ctrl + Right Arrow  : move one tab to the right
- Alt + W             : return to the previously active tab

Alt + W remembers real tab activation, including clicking from tab 1
directly to tab 5. Press Alt + W again to return to tab 5.
History is separate for each Chrome window.

INSTALLATION:
1. Extract Tab-Controller.zip.
2. Open chrome://extensions in Google Chrome.
3. Enable Developer mode (top right).
4. Click Load unpacked.
5. Select the unzipped tab-controller folder, not the ZIP itself.
6. Optionally pin the extension for on-screen controls.
7. Open chrome://extensions/shortcuts and verify the three shortcuts
   appear for Tab Controller. If Chrome did not assign any, click the
   shortcut field and enter the preferred key combination manually.

BEHAVIOR:
- Left/right wraps: first tab + Left -> last; last tab + Right -> first.
- Does not close, reorder, or change any tabs beyond activating one.
- First use of Alt+W: switch tabs once so there's a tab to return to.
- Closing the previous tab clears that history entry.
- Switches are tracked within each Chrome window, not across windows.
- Keyboard commands apply when Chrome is focused; not system-wide.
- Keys that Chrome, Windows or a webpage reserves may take precedence.
- Ctrl+Left / Ctrl+Right normally move the caret by word in text inputs;
  assigning them as Chrome shortcuts may override that behavior.
- If a preferred shortcut conflicts with Chrome/Windows, you can use
  chrome://extensions/shortcuts to assign an alternate combination.

PRIVACY:
- Stores only tab IDs in Chrome session storage for tab history.
- Data is discarded when the browser session ends.
- No account, server, external libraries, requests or content scripts.
- 'tabs' permission is used only to list/activate tabs and show titles.

This works independently of QuickTab Organizer. Both can be installed.
