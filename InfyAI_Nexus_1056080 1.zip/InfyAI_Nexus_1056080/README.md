# Northline Market — auditable product advisor

> **One-line value proposition:** MarketGuide turns a 1,000-product aisle into five constraint-safe, explainable choices per persona—25/25 hard-compliant in the supplied run, with every decision reproducible from versioned local evidence.

## Team name and members

- Team name: InfyAI Nexus
- Members:
  - Prajjwal Sharma — product owner, business-rule reviewer, and submission owner
  - Codex — solution design, implementation, policy analysis, adversarial testing, and documentation

## Scenario chosen and why

| # | Scenario | The problem |
|---|---|---|
| 4 | **Northline Market — product advisor** | Search exposes 1,000 SKUs at once. Five frozen buyer personas need short, constraint-safe recommendations that a merchandiser can defend line by line. |

We chose this scenario because the problem is not merely search relevance. Northline needs a recommendation that can survive a merchandising meeting: hard requirements must never be traded away, subjective preferences must be made explicit, and every position needs evidence. That makes explainability and operational control as important as the numerical rank.

### Why this matters

- **For customers:** reduce the first-page decision surface from 1,000 products to five relevant choices—a 99.5% reduction.
- **For merchandising:** replace “the model thinks so” with hard checks, score components, contrastive explanations, and policy-risk alerts.
- **For Northline:** create a governed foundation for conversion improvement without fabricating inventory, margin, behavior, or uplift that the supplied folder cannot prove.

## What we built

At the start, Northline had a frozen 1,000-SKU catalog, five written buyer personas, and a formula that appeared complete but silently ignored some of those personas' preferences. We built **MarketGuide** (`northline_market`), a local standard-library-only Python agent that turns those files into five short, auditable recommendation lists.

The finished agent validates catalog, persona, and agent configuration as policy-bearing data; records the plan for each persona; removes every hard-rule failure; ranks the remaining products; verifies its own invariants; diagnoses fragile decisions; and writes audit-grade JSON and Markdown artifacts. The final supplied-data run produced 25 constraint-safe recommendations and the 19-test suite passes.

The default `complete` profile repairs a defect in the supplied formula: the published `tag_overlap` term ignores three declared numeric soft fields. The agent preserves the 40% price / 30% rating / 30% preference weights but makes the final 30% the mean satisfaction of **all atomic stated preferences**. A `published` profile reproduces the original behavior for comparison and rollback.

### What makes it innovative

| Differentiator | Why judges and stakeholders should care |
|---|---|
| **Policy audit, not blind implementation** | The agent found three unused persona fields; the repair changed 16/25 positions, four top-five memberships, and two winners. |
| **Bounded autonomy** | MarketGuide plans and executes independently but cannot relax hard rules, self-modify weights, or publish without human approval. |
| **Independent critic and diagnostics** | Invariants block invalid output; quality alerts surface price dominance and unstable decisions without silently changing policy. |
| **Explicit memory** | Catalog, persona, and config hashes plus plan, checks, scores, alerts, and artifact hashes make every run replayable. |
| **Adversarial evaluation** | A deterministic generator adds 150 synthetic price challengers, preference champions, boundary passes, and random valid products. |

### Features

- Explicit hard-rule codes: `H-CATEGORY`, `H-MAX-PRICE`, `H-MIN-BATTERY`, `H-MIN-RAM`, `H-MIN-RATING`, `H-MIN-INCHES`, and `H-REQUIRED-TAGS`.
- Deterministic top-five ranking: total score, then higher rating, lower price, and SKU as a final stability key.
- Evidence per recommendation: raw product fields, score components, every hard check, preference satisfaction, why it fits, and why it beat the next eligible item (rank five is compared with rank six).
- Explicit persona plans, primary/non-exclusive exclusion counts, input/config hashes, versioned policy, stable run ID, and zero-network declaration.
- Quality-review signals for low preference fit, tight margins/cutoffs, short lists, and price dominance; signals never silently alter rank.
- Validated `config/agent_config.json` as the single source for versions, weights, normalization, tie-breaks, and diagnostic thresholds.
- Atomic JSON/Markdown replacement plus `artifact_manifest.json` as the hash-based commit marker.
- One-command profile comparison and 150 deterministic synthetic products for boundary and formula-sensitivity evaluation.
- An editable 18-slide stakeholder PowerPoint and matching PDF, both with presenter notes and native diagrams.
- Strict failure on duplicate SKUs, malformed numbers/tags, unknown rule keys, invalid JSON/schema, or unreadable files. Missing numeric catalog values mean “not applicable” and fail a hard minimum; they are never converted to zero.
- Graceful empty-candidate state for review, with optional fail-closed behavior.

### Install and run

Requirements are Python 3.10+ and the Python standard library. There is no package install, API key, model endpoint, commerce service, or network call.

```powershell
python -m northline_market
```

This writes `outputs/recommendations.json`, `outputs/report.md`, and `outputs/artifact_manifest.json`. Useful variants:

```powershell
python -m northline_market --profile published --output-dir outputs/published
python -m northline_market --compare-profiles --output-dir outputs/comparison
python -m northline_market --validate-only
python -m northline_market --fail-on-empty
python -m northline_market --catalog data/product_catalog.csv --personas data/customer_personas.json --output-dir outputs
python -m northline_market.samples --count 150 --seed 42
python -m unittest discover -s tests -v
```

The CLI returns `0` on success and `2` for a validation, policy, file, or fail-on-empty error. Output files are replaced atomically so a failed run does not leave a half-written recommendation set.

### 90-second demo walkthrough

1. Run `python -m northline_market --validate-only` to prove all three contracts are valid.
2. Run `python -m northline_market`; point to the five persona summaries and the three personas flagged for policy review.
3. Open `outputs/report.md`; use `P-DESIGN` to show why `SKU-0092` passes every hard rule and beats the next product.
4. Run `python -m northline_market --compare-profiles --output-dir outputs/comparison`; show the generated 16/25 rank-change evidence.
5. Run `python -m unittest discover -s tests -v`; finish on `Ran 19 tests ... OK`.

Presentation assets: `Northline_MarketGuide_Stakeholder_Deck.pptx`, `Northline_MarketGuide_Stakeholder_Deck.pdf`, and `PRESENTATION_OUTLINE.md`. Regenerate them on Windows with `& .\scripts\run_deck_generator.ps1`.

## Architecture

```mermaid
flowchart LR
    A["Local catalog CSV"] --> V["Validate and normalize"]
    B["Persona policy JSON"] --> V
    C["Versioned agent config"] --> V
    V --> P["Plan applicable rules per persona"]
    P --> F["Hard-constraint filter"]
    F --> S["Complete or published scorer"]
    S --> R["Deterministic rank and top k+1"]
    R --> G["Invariant guard"]
    G --> Q["Quality diagnostics"]
    Q --> E["Evidence and contrast explanations"]
    E --> J["recommendations.json"]
    E --> M["report.md"]
    J --> H["artifact_manifest.json"]
    M --> H
```

`io.py` owns trust-boundary validation and input hashes. `config.py` validates the external agent policy. `models.py` provides immutable domain records. `policy.py` contains pure decision functions. `agent.py` owns planning, orchestration, self-checks, and diagnostics. `reporting.py` persists artifacts and their commit manifest. `evaluation.py` compares profiles; `samples.py` creates synthetic robustness data; `cli.py` owns user controls. This separation lets merchandising review policy changes without conflating them with parsing or presentation. See `docs/ARCHITECTURE.md` and `docs/IMPROVEMENT_LOG.md`.

The agent's durable memory is explicit, not conversational: catalog, persona, and configuration SHA-256 hashes plus profile/policy versions produce a stable run ID. Every persona records its plan and quality alerts. The workflow is stateless between runs and reproducible from the three inputs.

### Agentic capability map

| Capability | MarketGuide evidence |
|---|---|
| Perceive | Strictly loads and validates catalog, persona contract, and versioned agent configuration. |
| Plan | Records objective, candidate scope, rule codes, preference atoms, weights, tie-breaks, `k`, and fallback per persona. |
| Act | Hard-filters, scores, ranks, and produces up to five recommendations autonomously. |
| Reflect/critic | Rechecks hard compliance, uniqueness, order, tight margins, low fit, short lists, and price dominance. |
| Tools | Uses local schema, policy, evaluation, reporting, hashing, and synthetic-generation modules; zero network calls. |
| Memory | Persists hashes, versions, plans, evidence, diagnostics, and output hashes; no hidden cross-run state. |
| Human boundary | Merchandising approves weights and publication; the agent fails closed on unknown policy. |

There is deliberately no runtime natural-language prompt. Under the brief's “Codex is the runtime, no separate model API” constraint, the prompt-equivalent control surface is the validated combination of persona JSON, agent configuration, schemas, and pure policy functions. This improves repeatability and prevents prompt drift.

## ADRs

### ADR 1 — Complete all declared soft preferences

- **Status:** accepted
- **Decision:** Keep the published component weights, but replace tag-only overlap with the mean of atomic tag, weight, battery, and preferred-rating satisfaction. Tags score 0/1. “Below” weight scores `min(threshold / actual, 1)`; “above” battery scores `min(actual / threshold, 1)`; preferred rating progresses from the formula's 3.5 floor to the stated target.
- **Alternative rejected:** Apply the published formula verbatim as the default.
- **Why, and what it costs us:** The original silently discards `prefer_weight_kg_below`, `prefer_battery_hours_above`, and `prefer_rating_above`. The repair changed 16 of 25 rank positions and four top-five memberships, so it is material. Equal atomic preferences are an assumption; a business owner may prefer persona-specific weights.

### ADR 2 — Deterministic policy agent, not an LLM ranking step

- **Status:** accepted
- **Decision:** Use code for constraint evaluation, ranking, self-checking, and template-grounded explanations. Codex is the development/runtime environment, but no model API is called during execution.
- **Alternative rejected:** Ask a language model or a committee of agents to judge every product.
- **Why, and what it costs us:** The brief prohibits a separate model service, and hard requirements need reproducibility. The cost is bounded language and no inference from product names; that is desirable until merchandising defines a governed ontology.

### ADR 3 — Fail on unknown policy, not open

- **Status:** accepted
- **Decision:** Reject an unknown hard or soft key and malformed input before ranking. Continue with an explicit `no_eligible_products` result when valid rules yield no candidate; `--fail-on-empty` turns that into a non-zero run.
- **Alternative rejected:** Ignore unknown rules or silently relax a constraint.
- **Why, and what it costs us:** A plausible list that omitted a new requirement is more dangerous than no list. Weekly schema additions require a code/policy release before they run.

### ADR 4 — Do not invent inventory, margin, or behavioral signals

- **Status:** accepted
- **Decision:** Rank only on contract fields. `review_count` is emitted as evidence but is not a persona preference and therefore does not affect the score.
- **Alternative rejected:** Add review popularity, stock, margin, or brand inference to improve commercial appeal.
- **Why, and what it costs us:** Inventory, margin, returns, and behavioral labels do not exist in this folder. Adding fabricated proxies would violate the local contract. Production needs those integrations before automatic customer exposure.

### ADR 5 — Diagnose policy risk; do not self-modify business weights

- **Status:** accepted
- **Decision:** Emit quality alerts for low preference fit, tight margins, short lists, and price dominance while preserving the configured rank.
- **Alternative rejected:** Let the agent autonomously retune weights whenever a result appears commercially odd.
- **Why, and what it costs us:** Weight changes affect customer and commercial outcomes and require merchandising authority. Alerts strengthen reasoning and autonomy without allowing policy drift; the cost is a human review step for flagged personas.

## What the brief did not tell us

1. **Numeric soft preferences were unused.** `customer_personas.json` declares weight for `P-STUDENT`/`P-TRAVEL`, battery for `P-ITBUY`, and preferred rating for `P-DESIGN`/`P-REMOTE`, while `soft_score` uses only preferred tags. The literal reading is the `published` profile. The intent-aligned reading is `complete`, chosen by default. Across 25 displayed positions, only nine remain in the same position; top choice changes for `P-STUDENT` and `P-TRAVEL`.
2. **Soft-threshold shape and relative weight are unspecified.** A Boolean threshold creates a cliff at, for example, 0.30 kg. We chose transparent bounded partial credit and equal weight per atomic preference. Ask merchandising whether each soft key, rather than each tag, should receive equal weight and whether satisfaction curves should be category-specific.
3. **Exact final tie is unspecified.** The contract ends at rating then price. SKU ascending is added only as a deterministic final key; it conveys no preference.
4. **Missing values are defined only at catalog level.** `DATA_DICT.md` says blanks are not applicable, not zero. A missing field therefore fails a hard minimum and scores zero for the corresponding soft preference. Category prevents most cross-category missing-value cases.
5. **No stock, margin, recency, returns, or real outcomes exist.** The brief asks about unwanted stock, but the extract cannot answer it. The agent does not pretend otherwise. In-stock eligibility must precede scoring in production, with margin/return metrics used as monitored outcomes rather than hidden rank factors unless policy owners approve them.
6. **Persona and catalog cadence is not specified.** Every run hashes both files; operations can detect a changed input. Production needs named owners, effective dates, and an approval workflow.
7. **Source format note.** The supplied `BRIEF_S4.md` companion was used as the machine-readable form of `BRIEF_S4.pdf`. `DS_Store` is filesystem metadata and contains no declared scenario input.

## How we would ship this at Northline

Run the validator and offline evaluation in CI whenever catalog, persona, or policy changes. A merchandising owner approves the diff between the last and candidate run; the approved version is immutable and signed with its hashes. A scheduled batch publishes to a recommendation store only after validation, coverage, hard-compliance, and artifact checks pass. The storefront remains outside this repository.

Before scoring, production would join live sellability/stock and suppress unavailable items. After serving, an analytics pipeline would record recommendation version, impression, click, product-detail engagement, add-to-cart, purchase, cancellation, and return without placing personal data in this agent's artifact. Product/merchandising owns relevance and policy; commerce engineering owns availability and runtime; data engineering owns event quality. Page commerce engineering on pipeline failure and merchandising on policy/coverage drift.

Controls: canary a new policy, retain the last approved artifact, provide one-click rollback to `published` or the prior approved run, require human approval for persona/rule changes, and log exclusions as well as recommendations. Turn serving off immediately for any hard-rule violation, hash mismatch, unknown rule, unavailable recommendation, or unexplained output mutation. Pause/rollback when persona coverage drops below five items, validation failures recur, or guarded conversion/return metrics cross pre-agreed thresholds.

Scale is linear in products × personas × rules. At 100× volume, stream/partition the catalog, calculate category indexes, and use an external artifact store; preserve the same pure rule functions and invariant checks.

### Expected impact and measurable outcomes

| Outcome | Prototype evidence | Production success measure |
|---|---|---|
| Choice reduction | 1,000 → 5 per persona (99.5%) | Five sellable choices whenever coverage permits |
| Hard compliance | 25/25 emitted products pass | 100%; any violation is a kill condition |
| Persona coverage | 5/5 personas receive five items | Coverage ≥ agreed threshold; alert below five |
| Decision auditability | Plan, checks, scores, explanations, alerts, hashes | 100% of served lists trace to an approved artifact |
| Merchandising efficiency | Meeting-ready report and generated diff | Measure approval lead time and manual rework reduction |
| Commercial value | Not measurable from the frozen folder | Guarded conversion/revenue-per-session lift with no return/cancellation degradation |

## Risks and limits

- Personas are marketing abstractions, not users; they can encode stereotypes and miss individual intent.
- Price receives 40% of the score and can dominate quality/preference signals. `P-TRAVEL` illustrates this: a $58.67 product outranks a product satisfying all three stated preferences. That result is faithful to the retained weights, but merchandising should review the weight.
- Equal atomic weighting means a persona with two preferred tags gives tags more combined influence than a single numeric preference. This is explicit, not proven optimal.
- Ratings may be stale/manipulated; review count is not a quality correction. There is no stock, margin, freshness, compatibility, brand, or return data.
- Template explanations are evidence-bound but not natural-language reasoning beyond available fields. They should not claim suitability outside the persona contract.
- No labelled relevance judgments or live experiment results exist, so offline correctness does not establish conversion lift.
- Files are processed in memory. This is safe for 1,000 rows, not an unbounded feed.

## What we would do with another day

1. Ask merchandising to sign off on component and atomic-preference weights after reviewing the published/complete diff, especially price dominance for travel.
2. Extend the generated adversarial catalog with malformed encodings and stale availability-feed scenarios.
3. Add inventory/sellability and freshness as hard preconditions, then test stale-feed shutdown behavior against synthetic data.
4. Add a signed approval registry and golden approved artifact for CI review.
5. Design a privacy-safe event contract and power analysis for a canary experiment; do not claim uplift before it runs.
6. Add streaming/indexed execution only when catalog scale demonstrates the need.

## Appendix

### Evaluation approach and observed results

The automated suite contains 19 tests covering all hard rules, tag-subset semantics, missing and non-finite values, numeric preferences, invalid configuration weights, published compatibility, deterministic ties, duplicates, unknown rules, empty candidates, explicit plans, quality diagnostics, artifact hashes, profile comparison, generator determinism, validation-only mode, and the five-persona end-to-end result. Run: `python -m unittest discover -s tests -v` (19/19 passing on 2026-08-19).

Offline gates are: 100% hard compliance; five-persona coverage; five recommendations whenever at least five candidates are eligible; stable output for identical hashes/profile/version; complete plan/score/hard/explanation evidence; a matching artifact manifest; and zero unknown rules. Quality alerts are review triggers, not automatic rank changes. Online success, once integrated, is guarded conversion or revenue-per-session lift with no degradation in availability, cancellation/return rate, latency, or hard compliance. Hard compliance has a zero-tolerance kill threshold.

| Persona | Eligible | Default #1 | Price | Rating | Score | Top-five membership changes vs published |
|---|---:|---|---:|---:|---:|---:|
| `P-STUDENT` | 16 | `SKU-0223` Reef 13 9 | $385.12 | 4.7 | 0.5543 | 0 |
| `P-ITBUY` | 48 | `SKU-0223` Reef 13 9 | $385.12 | 4.7 | 0.8700 | 1 |
| `P-TRAVEL` | 10 | `SKU-0742` Audio 368 | $58.67 | 4.1 | 0.6529 | 1 |
| `P-DESIGN` | 49 | `SKU-0092` View 32 17 | $189.07 | 4.8 | 0.8760 | 2 |
| `P-REMOTE` | 22 | `SKU-0250` Seat 37 | $107.80 | 4.5 | 0.7042 | 0 |

Failure counts in JSON are non-exclusive: one product can fail several hard rules, so they must not be summed to obtain excluded rows.

### Output example

For `P-STUDENT`, `SKU-0001` is third under the complete profile. It passes the $600, 12-hour battery, 3.8-rating, and laptop requirements and fully satisfies weight ≤1.5 kg plus both preferred tags. It stays above `SKU-0465` because its declared-preference advantage outweighs the latter's rating advantage. The full evidence and exact component values are in `outputs/recommendations.json`.

### Internal judge-readiness scorecard

| Criterion | Score / 10 | Evidence and remaining gap |
|---|---:|---|
| Problem alignment | 9.5 | Directly implements the five-persona contract and hard-gate requirement. |
| Innovation | 8.8 | Formula audit, reversible policy repair, diagnostics, and adversarial data; no novel ML model claimed. |
| Agentic capability | 8.7 | Explicit perceive-plan-act-critic-memory loop with bounded autonomy; deterministic rather than generative runtime. |
| Planning/reasoning | 9.2 | Recorded plans, hard evidence, contrastive explanations, and policy-risk alerts. |
| Tools/memory | 9.0 | Modular local tools, stable run identity, durable evidence, and commit manifest. |
| Technical quality | 9.4 | Versioned config, strict validation, 19 tests, deterministic outputs, zero network. |
| User experience | 8.0 | One-command CLI and two audience-specific artifacts; no visual application. |
| Scalability/operations | 8.2 | Clear production controls and linear design; no live service or availability integration. |
| Business value | 8.6 | Strong auditable decision reduction; conversion uplift remains unmeasured. |
| Completeness/presentation | 9.0 | Working implementation, sample data, profile diff, documentation, demo script, and stakeholder deck assets. |

**Estimated overall judge readiness: 8.8/10.** The fastest path to a higher score is a crisp live demo that leads with the formula defect, shows one traceable decision, and closes with the generated impact/quality evidence—not additional features.
