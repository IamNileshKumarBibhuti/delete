QUICKTAB ORGANIZER — Installation and usage
===========================================

INSTALL (Google Chrome on Windows)
1. Unzip QuickTab-Organizer.zip to a folder. Leave the folder there.
2. Open chrome://extensions/ in Chrome.
3. Turn ON Developer mode (top right).
4. Click Load unpacked; choose the extracted quicktab-organizer folder containing manifest.json.
5. Use the puzzle-piece Extensions menu to pin QuickTab Organizer.
6. Click its toolbar icon. The QuickTab side panel opens and stays open as you switch tabs.

CREATE CATEGORIES
Type category names such as Work, Learning or Shopping, and click + Add.

FASTEST WORKFLOW: CAPTURE MODE
1. With any normal website open, click "Capture tabs" under a category.
2. The current website is saved immediately.
3. Click other Chrome tabs (or Ctrl+Tab between tabs); each activated web tab is automatically saved in that category.
4. Click "Stop Capture" after finishing. Capture automatically stops after 10 minutes.
5. To start collecting into another category, click its "Capture tabs" button.

MIXED CATEGORIES (one-click sorting)
For each active Chrome tab, click "Save + Next" beside the category you want.
It saves that URL and automatically activates the next eligible web tab.
Then click a different category's "Save + Next", or the same one again.

BULK: PRESELECT A FEW TABS
Hold Ctrl while clicking tabs in the Chrome tab strip to highlight multiple tabs.
Then click "Save highlighted" under the category you want.

OPEN LINKS
* Click "Open all" beside a category to launch all of its saved URLs.
* Click "Show saved links", tick a subset, and click "Open selected".
* Click a saved link title to open just that link.
* Opening more than 40 tabs asks you to confirm first to avoid browser overload.

KEYBOARD SHORTCUT
Alt+Shift+S: Save the current tab to the last category you used.
If that shortcut doesn't work or conflicts with Windows, open
chrome://extensions/shortcuts and assign another combination.

NOTES
- The organizer categorizes by YOUR choices, NOT by website or hostname.
- A URL can belong to several categories. Different URLs on the same domain remain distinct.
- Duplicate exact URLs within the same category are saved once.
- It doesn't copy passwords, web page contents, or cookies.
- Links are stored in this browser profile's extension-local storage (not synced).
- Use Export backup regularly and Import backup to restore after reinstalling.
- Incognito browsing is not recorded unless you explicitly enable extension incognito access.
- Websites needing login may still prompt you to log in when reopened.
- Chrome internal URLs (chrome://...) are not saved.
- Chrome extension permissions: tabs, storage, and sidePanel; no host access and no network code.
- Use only with Chrome installed where you are permitted to load unpacked extensions.
