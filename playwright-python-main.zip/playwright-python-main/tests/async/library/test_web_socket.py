# Copyright (c) Microsoft Corporation.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Port of tests/library/web-socket.spec.ts."""

import asyncio
from typing import Any, Callable, List, Optional, Union

import pytest

from playwright.async_api import Error, Page, WebSocket
from tests.helpers import web_socket_server
from tests.server import Server, TestServerRequest, WebSocketProtocol
from tests.utils import TARGET_CLOSED_ERROR_MESSAGE


async def wait_for_web_socket_frame(page: Page, action: Callable[[], Any]) -> WebSocket:
    """Port of Promise.all([page.waitForEvent('websocket').then(ws => ws.waitForEvent('framereceived')), action()]).

    Like the .then() upstream, it listens to the frames of the WebSocket as the page
    reports it, so it does not miss a frame that arrives right after.
    """
    frame_received: "asyncio.Future[WebSocket]" = asyncio.Future()

    def on_web_socket(ws: WebSocket) -> None:
        ws.once("framereceived", lambda _: frame_received.set_result(ws))

    page.once("websocket", on_web_socket)
    await action()
    return await frame_received


async def test_WS_001_should_work_smoke(page: Page, server: Server) -> None:
    server.send_on_web_socket_connection(b"incoming")
    value = await page.evaluate(
        """host => {
            let cb;
            const result = new Promise(f => cb = f);
            const ws = new WebSocket('ws://' + host + '/ws');
            ws.addEventListener('message', data => { ws.close(); cb(data.data); });
            return result;
        }""",
        server.HOST,
    )
    assert value == "incoming"


async def test_WS_002_should_emit_close_events(page: Page, server: Server) -> None:
    socket_closed: "asyncio.Future[None]" = asyncio.Future()
    log: List[str] = []
    web_socket: Optional[WebSocket] = None

    def on_web_socket(ws: WebSocket) -> None:
        nonlocal web_socket
        log.append(f"open<{ws.url}>")
        web_socket = ws

        def on_close(_: WebSocket) -> None:
            log.append("close")
            socket_closed.set_result(None)

        ws.on("close", on_close)

    page.on("websocket", on_web_socket)
    await page.evaluate(
        """host => {
            const ws = new WebSocket('ws://' + host + '/ws');
            ws.addEventListener('open', () => ws.close());
        }""",
        server.HOST,
    )
    await socket_closed
    assert ":".join(log) == f"open<ws://{server.HOST}/ws>:close"
    assert web_socket
    assert web_socket.is_closed()


async def test_WS_003_should_emit_frame_events(page: Page, server: Server) -> None:
    def on_connection(ws: WebSocketProtocol) -> None:
        ws.events.on(
            "message", lambda payload, is_binary: ws.sendMessage(b"incoming", False)
        )

    server.once_web_socket_connection(on_connection)
    socket_closed: "asyncio.Future[None]" = asyncio.Future()
    log: List[str] = []

    def on_web_socket(ws: WebSocket) -> None:
        log.append("open")
        ws.on("framesent", lambda payload: log.append(f"sent<{payload!s}>"))
        ws.on("framereceived", lambda payload: log.append(f"received<{payload!s}>"))

        def on_close(_: WebSocket) -> None:
            log.append("close")
            socket_closed.set_result(None)

        ws.on("close", on_close)

    page.on("websocket", on_web_socket)
    await page.evaluate(
        """host => {
            const ws = new WebSocket('ws://' + host + '/ws');
            ws.addEventListener('open', () => ws.send('outgoing'));
            ws.addEventListener('message', () => { ws.close(); });
            window.ws = ws;
        }""",
        server.HOST,
    )
    await socket_closed
    assert log == ["open", "sent<outgoing>", "received<incoming>", "close"]


async def test_WS_004_should_filter_out_the_close_events_when_the_server_closes_with_a_message(
    page: Page, server: Server
) -> None:
    def on_connection(ws: WebSocketProtocol) -> None:
        ws.sendMessage(b"incoming", False)
        ws.events.on(
            "message",
            lambda payload, is_binary: web_socket_server.close_on_reactor_thread(
                ws, 1003, "closed by Playwright test-server"
            ),
        )

    server.once_web_socket_connection(on_connection)
    socket_closed: "asyncio.Future[None]" = asyncio.Future()
    log: List[str] = []

    def on_web_socket(ws: WebSocket) -> None:
        log.append("open")
        ws.on("framesent", lambda payload: log.append(f"sent<{payload!s}>"))
        ws.on("framereceived", lambda payload: log.append(f"received<{payload!s}>"))

        def on_close(_: WebSocket) -> None:
            log.append("close")
            socket_closed.set_result(None)

        ws.on("close", on_close)

    page.on("websocket", on_web_socket)
    await page.evaluate(
        """host => {
            const ws = new WebSocket('ws://' + host + '/ws');
            ws.addEventListener('message', () => ws.send('outgoing'));
            window.ws = ws;
        }""",
        server.HOST,
    )
    await socket_closed
    assert log == ["open", "received<incoming>", "sent<outgoing>", "close"]


async def test_WS_005_should_pass_self_as_argument_to_close_event(
    page: Page, server: Server
) -> None:
    socket_closed: "asyncio.Future[WebSocket]" = asyncio.Future()
    web_socket: Optional[WebSocket] = None

    def on_web_socket(ws: WebSocket) -> None:
        nonlocal web_socket
        web_socket = ws
        ws.on("close", lambda arg: socket_closed.set_result(arg))

    page.on("websocket", on_web_socket)
    await page.evaluate(
        """host => {
            const ws = new WebSocket('ws://' + host + '/ws');
            ws.addEventListener('open', () => ws.close());
        }""",
        server.HOST,
    )
    event_arg = await socket_closed
    assert event_arg is web_socket


async def test_WS_006_should_emit_binary_frame_events(
    page: Page, server: Server
) -> None:
    done: "asyncio.Future[None]" = asyncio.Future()
    sent: List[Union[str, bytes]] = []

    def on_web_socket(ws: WebSocket) -> None:
        ws.on("close", lambda _: done.set_result(None))
        ws.on("framesent", lambda payload: sent.append(payload))

    page.on("websocket", on_web_socket)
    await page.evaluate(
        """host => {
            const ws = new WebSocket('ws://' + host + '/ws');
            ws.addEventListener('open', () => {
                const binary = new Uint8Array(5);
                for (let i = 0; i < 5; ++i)
                    binary[i] = i;
                ws.send('text');
                ws.send(binary);
                ws.close();
            });
        }""",
        server.HOST,
    )
    await done
    assert sent[0] == "text"
    for i in range(5):
        assert sent[1][i] == i


async def test_WS_007_should_emit_error(
    page: Page, server: Server, browser_channel: Optional[str]
) -> None:
    result: "asyncio.Future[str]" = asyncio.Future()

    def on_socket_error(error: str) -> None:
        if not result.done():
            result.set_result(error)

    page.on("websocket", lambda ws: ws.on("socketerror", on_socket_error))
    await page.evaluate(
        """host => {
            new WebSocket('ws://' + host + '/bogus-ws');
        }""",
        server.HOST,
    )
    message = await result
    assert ("" if browser_channel and "msedge" in browser_channel else ": 400") in (
        message
    )


async def test_WS_008_should_not_have_stray_error_events(
    page: Page, server: Server
) -> None:
    server.send_on_web_socket_connection(b"incoming")
    error: List[str] = []

    def on_web_socket(ws: WebSocket) -> None:
        ws.on("socketerror", lambda e: error.append(e))

    page.on("websocket", on_web_socket)
    await wait_for_web_socket_frame(
        page,
        lambda: page.evaluate(
            """host => {
                window.ws = new WebSocket('ws://' + host + '/ws');
            }""",
            server.HOST,
        ),
    )
    await page.evaluate("window.ws.close()")
    assert not error


async def test_WS_009_should_reject_wait_for_event_on_socket_close(
    page: Page, server: Server
) -> None:
    server.send_on_web_socket_connection(b"incoming")
    ws = await wait_for_web_socket_frame(
        page,
        lambda: page.evaluate(
            """host => {
                window.ws = new WebSocket('ws://' + host + '/ws');
            }""",
            server.HOST,
        ),
    )
    with pytest.raises(Error) as exc_info:
        async with ws.expect_event("framesent"):
            await page.evaluate("window.ws.close()")
    assert "Socket closed" in exc_info.value.message


async def test_WS_010_should_reject_wait_for_event_on_page_close(
    page: Page, server: Server
) -> None:
    server.send_on_web_socket_connection(b"incoming")
    ws = await wait_for_web_socket_frame(
        page,
        lambda: page.evaluate(
            """host => {
                window.ws = new WebSocket('ws://' + host + '/ws');
            }""",
            server.HOST,
        ),
    )
    with pytest.raises(Error) as exc_info:
        async with ws.expect_event("framesent"):
            await page.close()
    assert TARGET_CLOSED_ERROR_MESSAGE in exc_info.value.message


async def test_WS_011_should_not_tear_down_the_page_when_a_web_socket_is_opened_inside_a_worker(
    page: Page, server: Server
) -> None:
    # https://github.com/microsoft/playwright/issues/41742
    server.send_on_web_socket_connection(b"incoming")
    await page.goto(server.EMPTY_PAGE)
    received = await page.evaluate(
        """host => {
            const code = `
              const ws = new WebSocket(${JSON.stringify('ws://' + host + '/ws')});
              ws.addEventListener('message', event => self.postMessage(event.data));
            `;
            const worker = new Worker(URL.createObjectURL(new Blob([code], { type: 'text/javascript' })));
            return new Promise(resolve => worker.addEventListener('message', event => resolve(event.data)));
        }""",
        server.HOST,
    )
    assert received == "incoming"
    # Opening a `WebSocket` inside a worker must not tear down the page session.
    assert await page.evaluate("() => 1 + 1") == 2


async def test_WS_012_should_turn_off_when_offline(page: Page, server: Server) -> None:
    pytest.skip("fixme")

    socket_promise = server.wait_for_web_socket()
    ws_handle = await page.evaluate_handle(
        """async address => {
            const ws = new WebSocket(`ws://${address}/ws`);
            await new Promise(x => ws.onopen = x);
            return ws;
        }""",
        server.HOST,
    )
    socket = await socket_promise
    failures: List[str] = []
    socket.events.on(
        "message",
        lambda payload, is_binary: failures.append(web_socket_server.to_text(payload)),
    )
    await page.context.set_offline(True)
    await ws_handle.evaluate("ws => ws.send('if this arrives it failed')")
    result = await ws_handle.evaluate(
        """async ws => {
            if (ws.readyState !== WebSocket.CLOSED)
                await new Promise(x => ws.onclose = x);
            return 'successfully closed';
        }"""
    )
    assert failures == []
    assert result == "successfully closed"


async def test_WS_013_should_send_extra_http_headers_on_web_socket_handshake(
    page: Page, server: Server, browser_name: str, browser_major_version: int
) -> None:
    # https://github.com/microsoft/playwright/issues/28948
    if browser_name == "chromium" and browser_major_version < 151:
        pytest.skip(
            "fixme: Chromium before 151 does not send extra HTTP headers on WebSocket handshake"
        )

    await page.set_extra_http_headers({"foo": "bar"})
    await page.goto(server.EMPTY_PAGE)
    request_promise = server.wait_for_web_socket_connection_request()
    await page.evaluate(
        "host => { new WebSocket(`ws://${host}/ws`); }",
        server.HOST,
    )
    request = await request_promise
    assert request.headers["foo"] == "bar"


async def test_WS_014_should_send_extra_http_headers_on_web_socket_handshake_from_a_worker(
    page: Page, server: Server, browser_name: str, browser_major_version: int
) -> None:
    # https://github.com/microsoft/playwright/issues/28948
    if browser_name == "chromium" and browser_major_version < 151:
        pytest.skip(
            "fixme: Chromium before 151 does not send extra HTTP headers on WebSocket handshake"
        )

    await page.set_extra_http_headers({"foo": "bar"})
    await page.goto(server.EMPTY_PAGE)
    request_promise = server.wait_for_web_socket_connection_request()
    await page.evaluate(
        """host => {
            const code = `new WebSocket(${JSON.stringify('ws://' + host + '/ws')});`;
            new Worker(URL.createObjectURL(new Blob([code], { type: 'text/javascript' })));
        }""",
        server.HOST,
    )
    request = await request_promise
    assert request.headers["foo"] == "bar"


async def test_WS_041_should_navigate_while_an_iframe_opens_web_sockets(
    page: Page, server: Server
) -> None:
    def parent(req: TestServerRequest) -> None:
        req.setHeader("Content-Type", "text/html")
        req.write(b'<iframe src="/child"></iframe>')
        req.finish()

    def child(req: TestServerRequest) -> None:
        req.setHeader("Content-Type", "text/html")
        req.write(
            b"<script>setInterval(() => new WebSocket('ws://' + location.host + '/ws'), 5)</script>"
        )
        req.finish()

    server.set_route("/parent", parent)
    server.set_route("/child", child)
    for _ in range(20):
        await page.goto(server.PREFIX + "/parent")
    assert len(page.frames) == 2
    assert await page.evaluate("() => 1 + 1") == 2
