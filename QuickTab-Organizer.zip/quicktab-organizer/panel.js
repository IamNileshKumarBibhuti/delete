const categoriesEl = document.getElementById("categories");
const statusEl = document.getElementById("status");
const bannerEl = document.getElementById("captureBanner");
const totalEl = document.getElementById("total");
let state = {categories: [], capture: null};
const expanded = new Set();
let busy = false;

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
function btn(label, cls, fn) {
  const b = el("button", cls || "", label);
  b.type = "button";
  b.addEventListener("click", fn);
  return b;
}
function status(message, error = false) {
  statusEl.textContent = message;
  statusEl.classList.toggle("error", error);
}
function message(type, extra = {}) {
  return chrome.runtime.sendMessage({type, ...extra}).then(r => {
    if (!r?.ok) throw new Error(r?.error || "The operation failed.");
    return r;
  });
}
async function work(label, operation) {
  if (busy) return;
  busy = true;
  try {
    const result = await operation();
    if (result?.state) state = result.state;
    status(label);
    await refresh();
  } catch (err) { status(err.message, true); }
  finally { busy = false; }
}
async function refresh() {
  try { state = (await message("getState")).state; render(); }
  catch (err) {status(err.message, true);}
}
function render() {
  categoriesEl.replaceChildren();
  const count = state.categories.reduce((n, c) => n + c.links.length, 0);
  totalEl.textContent = `${state.categories.length} categories · ${count} links`;
  bannerEl.replaceChildren();
  if (state.capture) {
    const active = state.categories.find(c => c.id === state.capture.categoryId);
    bannerEl.hidden = false;
    bannerEl.append(el("strong", "", `● CAPTURING: ${active?.name || "Unknown"}`));
    bannerEl.append(el("p", "", "Switch through tabs in this Chrome window; each visited URL is saved. Stops automatically after 10 minutes."));
    bannerEl.append(btn("Stop capturing", "", () => work("Capture stopped.", () => message("stopCapture"))));
  } else { bannerEl.hidden = true; }
  if (!state.categories.length) {
    const empty = el("div", "empty");
    empty.append(el("strong", "", "Create your first category"));
    empty.append(el("span", "", "Then save tabs without copying URLs."));
    categoriesEl.append(empty);
    return;
  }
  for (const cat of state.categories) renderCategory(cat);
}
function renderCategory(cat) {
  const active = state.capture?.categoryId === cat.id;
  const root = el("article", `category${active ? " active" : ""}`);
  const heading = el("div", "cat-heading");
  const label = el("div", "cat-title", cat.name);
  label.append(el("span", "count", `${cat.links.length}`));
  heading.append(label);
  const opts = el("div", "cat-head-actions");
  opts.append(btn("Rename", "small", () => {
    const name = prompt("New category name:", cat.name);
    if (name !== null && name.trim()) work("Renamed.", () => message("renameCategory", {id: cat.id, name}));
  }));
  opts.append(btn("×", "small danger", () => {
    if (confirm(`Delete the category "${cat.name}" and its ${cat.links.length} saved links?`)) {
      work("Category removed.", () => message("removeCategory", {id: cat.id}));
    }
  }));
  heading.append(opts);
  root.append(heading);
  const actions = el("div", "actions");
  actions.append(btn("Save + Next →", "save", () => work(`Saved current tab to ${cat.name}; moved to next tab.`, () => message("saveAndNext", {id: cat.id}))));
  actions.append(btn(active ? "■ Stop Capture" : "● Capture tabs", `capture${active ? " recording" : ""}`, () => work(active ? "Capture stopped." : `Capturing ${cat.name}. Switch Chrome tabs now.`, () => message(active ? "stopCapture" : "startCapture", {id: cat.id}))));
  actions.append(btn("Open all ↗", "open", () => {if(cat.links.length > 40 && !confirm(`Open ${cat.links.length} Chrome tabs at once? This may slow down your browser.`)) return; work(`Opened ${cat.name} links.`, () => message("openAll", {id: cat.id}));}));
  actions.append(btn("Save highlighted", "", () => work(`Saved highlighted Chrome tabs to ${cat.name}.`, () => message("saveHighlighted", {id: cat.id}))));
  root.append(actions);
  const details = el("div", "details");
  const toggle = btn(expanded.has(cat.id) ? "▴ Hide saved links" : "▾ Show saved links / select some", "", () => {
    if (expanded.has(cat.id)) expanded.delete(cat.id); else expanded.add(cat.id);
    render();
  });
  toggle.style.width = "100%";
  details.append(toggle);
  if (expanded.has(cat.id)) {
    if (!cat.links.length) details.append(el("p", "", "No links saved here yet."));
    const list = el("div", "link-list");
    for (const link of cat.links) {
      const row = el("div", "link-row");
      const check = el("input");check.type = "checkbox";check.className="link-check";check.value=link.url;check.setAttribute("aria-label", `Select ${link.title}`);
      const copy = el("div", "link-copy");
      const title = el("a", "link-title", link.title || link.url);
      title.href = link.url; title.target = "_blank"; title.rel = "noopener noreferrer";
      title.title = link.url;
      copy.append(title);
      copy.append(el("span", "link-url", link.url));
      row.append(check, copy, btn("×", "small danger", () => work("Saved link removed.", () => message("removeLink", {id: cat.id, url: link.url}))));
      list.append(row);
    }
    details.append(list);
    if (cat.links.length) {
      const opts = el("div", "selected-buttons");
      opts.append(btn("Select all", "small", () => list.querySelectorAll(".link-check").forEach(c => c.checked=true)));
      opts.append(btn("Open selected ↗", "primary small", () => {
        const urls = Array.from(list.querySelectorAll(".link-check:checked")).map(c=>c.value);
        if (!urls.length) return status("Tick one or more links first.", true);
        if (urls.length > 40 && !confirm(`Open ${urls.length} Chrome tabs at once?`)) return;
        work(`Opened ${urls.length} selected link(s).`, () => message("openSelected", {id: cat.id, urls}));
      }));
      details.append(opts);
    }
  }
  root.append(details);
  categoriesEl.append(root);
}

document.getElementById("addForm").addEventListener("submit", event => {
  event.preventDefault();
  const field = document.getElementById("categoryName");
  const name = field.value.trim();
  if (!name) return;
  work(`Created ${name}.`, () => message("createCategory", {name}));
  field.value = "";
});

document.getElementById("exportBtn").addEventListener("click", async () => {
  const data = (await message("getState")).state;
  const backup = JSON.stringify({exportedAt: new Date().toISOString(), categories: data.categories}, null, 2);
  const blob = new Blob([backup], {type: "application/json"});
  const url = URL.createObjectURL(blob);
  const anchor = el("a");anchor.href=url;anchor.download=`quicktab-backup-${new Date().toISOString().slice(0,10)}.json`;
  document.body.append(anchor); anchor.click(); anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  status("Backup exported. Keep your JSON file safe.");
});
document.getElementById("importBtn").addEventListener("click", () => document.getElementById("importFile").click());
document.getElementById("importFile").addEventListener("change", async event => {
  const file = event.target.files?.[0];if (!file) return;
  try {
    if (file.size > 5_000_000) throw new Error("Backup exceeds 5 MB.");
    const data = JSON.parse(await file.text());
    await work("Backup imported as new categories; existing categories kept.", () => message("importData", {data}));
  } catch (err) {status(`Cannot import: ${err.message}`, true);}
  event.target.value="";
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.quicktabData) {
    state = changes.quicktabData.newValue || {categories:[],capture:null};
    render();
  }
});
refresh();
