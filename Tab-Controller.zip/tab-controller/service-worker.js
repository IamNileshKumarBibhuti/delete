/*
 * Tab Controller – Chrome MV3 service worker
 * No content scripts, website access, telemetry, or external dependencies.
 * The most-recent tab pair is maintained separately for each Chrome window.
 */
"use strict";

const STORAGE_KEY = "tabControllerHistoryV1";
let historyByWindow = {};
let historyLoaded = false;
let queue = Promise.resolve();

// Browser events and shortcut commands can arrive almost simultaneously.
// Serialize operations so a rapid Alt+W press still toggles predictably.
function serialized(task) {
  const work = queue.then(async () => {
    await loadHistory();
    return task();
  });
  queue = work.catch((error) => {
    console.error("Tab Controller:", error);
  });
  return work;
}

async function loadHistory() {
  if (historyLoaded) return;
  const saved = await chrome.storage.session.get(STORAGE_KEY);
  const value = saved[STORAGE_KEY];
  historyByWindow = value && typeof value === "object" && !Array.isArray(value)
    ? value
    : {};
  historyLoaded = true;
}

async function persist() {
  await chrome.storage.session.set({ [STORAGE_KEY]: historyByWindow });
}

function trackActivation(windowId, tabId) {
  if (!Number.isInteger(windowId) || !Number.isInteger(tabId)) return false;
  const key = String(windowId);
  const previousState = historyByWindow[key] || { current: null, previous: null };
  if (previousState.current === tabId) return false;
  historyByWindow[key] = {
    current: tabId,
    previous: previousState.current ?? null
  };
  return true;
}

async function getFocusedTab() {
  const activeTabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return activeTabs[0] || null;
}

async function validatePrevious(previousId, windowId, activeId) {
  if (!Number.isInteger(previousId) || previousId === activeId) return null;
  try {
    const previousTab = await chrome.tabs.get(previousId);
    return previousTab.windowId === windowId ? previousTab : null;
  } catch {
    return null; // The previous tab was closed or moved out of the window.
  }
}

async function perform(action) {
  return serialized(async () => {
    const activeTab = await getFocusedTab();
    if (!activeTab) return { ok: false, error: "No active Chrome tab found." };

    if (trackActivation(activeTab.windowId, activeTab.id)) await persist();
    const record = historyByWindow[String(activeTab.windowId)];
    let target;

    if (action === "go-previous") {
      target = await validatePrevious(record.previous, activeTab.windowId, activeTab.id);
      if (!target) {
        // Don't let an old, no-longer-existing tab keep showing as Previous.
        if (record.previous !== null) {
          record.previous = null;
          await persist();
        }
        return { ok: false, error: "No previous open tab yet. Switch to another tab first." };
      }
    } else if (action === "go-left" || action === "go-right") {
      const tabs = await chrome.tabs.query({ windowId: activeTab.windowId });
      tabs.sort((a, b) => a.index - b.index);
      if (tabs.length < 2) {
        return { ok: false, error: "Open at least two tabs to switch." };
      }
      const position = tabs.findIndex((tab) => tab.id === activeTab.id);
      if (position < 0) return { ok: false, error: "Active tab was not found." };
      const direction = action === "go-left" ? -1 : 1;
      target = tabs[(position + direction + tabs.length) % tabs.length];
    } else {
      return { ok: false, error: "Unknown command." };
    }

    try {
      await chrome.tabs.update(target.id, { active: true });
      // Pre-track the switch. onActivated will see this tab already recorded,
      // preventing a rapid subsequent Alt+W from losing the toggle history.
      if (trackActivation(activeTab.windowId, target.id)) await persist();
      return { ok: true, tabId: target.id };
    } catch {
      return { ok: false, error: "Could not activate that tab. It may have been closed." };
    }
  });
}

async function getStatus() {
  return serialized(async () => {
    const current = await getFocusedTab();
    if (!current) return { ok: false, error: "No active Chrome tab found." };
    if (trackActivation(current.windowId, current.id)) await persist();
    const record = historyByWindow[String(current.windowId)];
    const previous = await validatePrevious(record.previous, current.windowId, current.id);
    if (!previous && record.previous !== null) {
      record.previous = null;
      await persist();
    }
    return {
      ok: true,
      current: { id: current.id, title: current.title || "Current tab", url: current.url || "" },
      previous: previous
        ? { id: previous.id, title: previous.title || "Previous tab", url: previous.url || "" }
        : null
    };
  });
}

// Record every tab switch, including switches by mouse, native shortcuts,
// extensions, or web automation. This is what makes the Alt+W toggle useful.
chrome.tabs.onActivated.addListener(({ windowId, tabId }) => {
  void serialized(async () => {
    if (trackActivation(windowId, tabId)) await persist();
  });
});

chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
  void serialized(async () => {
    const record = historyByWindow[String(removeInfo.windowId)];
    if (!record) return;
    let changed = false;
    if (record.current === tabId) {
      record.current = null;
      changed = true;
    }
    if (record.previous === tabId) {
      record.previous = null;
      changed = true;
    }
    if (changed) await persist();
  });
});

chrome.tabs.onReplaced.addListener((addedTabId, removedTabId) => {
  void serialized(async () => {
    let changed = false;
    for (const record of Object.values(historyByWindow)) {
      if (record.current === removedTabId) {
        record.current = addedTabId;
        changed = true;
      }
      if (record.previous === removedTabId) {
        record.previous = addedTabId;
        changed = true;
      }
    }
    if (changed) await persist();
  });
});

chrome.windows.onRemoved.addListener((windowId) => {
  void serialized(async () => {
    if (historyByWindow[String(windowId)]) {
      delete historyByWindow[String(windowId)];
      await persist();
    }
  });
});

async function initializeWindowStates() {
  return serialized(async () => {
    const activeTabs = await chrome.tabs.query({ active: true });
    let changed = false;
    for (const tab of activeTabs) {
      if (trackActivation(tab.windowId, tab.id)) changed = true;
    }
    if (changed) await persist();
  });
}

chrome.runtime.onStartup.addListener(() => { void initializeWindowStates(); });
chrome.runtime.onInstalled.addListener(() => { void initializeWindowStates(); });

chrome.commands.onCommand.addListener((command) => {
  if (command === "go-left" || command === "go-right" || command === "go-previous") {
    void perform(command);
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || (message.type !== "navigate" && message.type !== "status")) return false;
  const operation = message.type === "status"
    ? getStatus()
    : perform(message.action);
  operation.then(sendResponse).catch((error) => {
    sendResponse({ ok: false, error: error.message || "Unknown error." });
  });
  return true;
});
