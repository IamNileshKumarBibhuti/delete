# Copyright (c) Microsoft Corporation.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""An HTTP server that answers every request with the same body, in both flavors.

Port of the dummyServerPort and ipV6ServerPort fixtures in
tests/library/browsertype-connect.spec.ts.
"""

import errno
import socket
import socketserver
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from tests.server import find_free_port


class FixedResponseServer:
    """Listens on host (only), on a free port, and answers every request with body."""

    def __init__(self, host: str, body: str) -> None:
        data = body.encode()

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:
                self.send_response(200)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def log_message(self, format: str, *args: Any) -> None:
                pass

        class Server(ThreadingHTTPServer):
            address_family = socket.AF_INET6 if ":" in host else socket.AF_INET

            def server_bind(self) -> None:
                # Not HTTPServer.server_bind(): its socket.getfqdn() looks the address
                # up in DNS, which can block for 30 seconds and more (::1 on macOS).
                socketserver.TCPServer.server_bind(self)
                self.server_name = host
                self.server_port = self.server_address[1]

        # A port that is free on both addresses, not one that is free on host only:
        # see find_free_port().
        for attempt in range(10):
            try:
                self._server = Server((host, find_free_port()), Handler)
                break
            except OSError as error:
                if error.errno != errno.EADDRINUSE or attempt == 9:
                    raise
        self._server.daemon_threads = True
        self.port: int = self._server.server_address[1]
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    def close(self) -> None:
        self._server.shutdown()
        self._server.server_close()
        self._thread.join()
