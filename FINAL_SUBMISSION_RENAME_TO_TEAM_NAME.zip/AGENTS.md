# AGENTS.md — Northline Market

## Goal

Recommend the best products for each customer persona while keeping the decision easy to explain and safe to review.

## Agent flow

```text
1. Input Agent
      ↓
2. Must-Have Rule Agent
      ↓
3. Official Ranking Agent
      ↓
4. Critic Agent
      ↓
5. Sensitivity Agent
      ↓
6. Edge-Case Test Agent
      ↓
7. Explanation Agent
      ↓
8. Human Decision (when needed)
```

## 1. Input Agent

### Job
Read and validate:

- `product_catalog.csv`
- `customer_personas.json`
- `DATA_DICT.md`

### Checks

- required columns exist;
- SKUs are unique;
- numbers are read correctly;
- empty numeric cells mean “not applicable”, not zero.

If the input is broken, the agent stops instead of guessing.

## 2. Must-Have Rule Agent

### Job
Remove any product that fails a mandatory customer rule.

Examples:

- laptop/headphones/monitor/chair must be the correct category;
- product must be inside the maximum budget;
- battery must meet the minimum;
- RAM must meet the minimum;
- rating must meet the minimum;
- monitor size must meet the minimum;
- required tags such as `wireless`, `anc` and `ergonomic` must exist.

### Safety rule

**Fail one must-have rule = do not recommend.**

The agent also records the reason for rejection.

## 3. Official Ranking Agent

### Job
Apply the exact scoring formula supplied in the dataset.

```text
score = 0.40 × price_fit
      + 0.30 × rating_norm
      + 0.30 × tag_overlap
```

It only scores products that already passed every must-have rule.

Ranking order:

1. higher score;
2. if tied, higher rating;
3. if still tied, lower price.

This gives us a fully reproducible baseline.

## 4. Critic Agent

### Job
Ask:

> “Does the official ranking really reflect everything this persona said they prefer?”

### Finding

The official formula uses:

- price;
- rating;
- preferred tags.

But some personas also contain preferences such as:

- weight below a target;
- battery above a target;
- rating above a persona-specific target.

Those extra preferences are not directly used by the official score.

The critic therefore flags high-ranked products that miss one of these written preferences.

It does **not** automatically reject them because these are preferences, not mandatory rules.

## 5. Sensitivity Agent

### Job
Show how the result may change if every written preference is allowed to influence ranking.

This is a comparison tool, not a silent rule change.

Why?

The persona file does not tell us how important weight should be compared with battery or rating. Choosing those business weights without approval would be another assumption.

So this agent:

- keeps the official result;
- creates a preference-complete comparison;
- shows rank changes;
- asks a merchandiser to approve any permanent formula change.

## 6. Edge-Case Test Agent

### Test 1: Formula gaming

Create a product that is extremely cheap and has ideal tags, but badly misses a written soft preference.

Purpose:

Check whether the official score can be pushed high by the fields it rewards while ignoring another customer preference.

### Test 2: Impossible persona

Create a persona whose must-have rules no product can satisfy.

Expected result:

**No recommendation.**

The agent must never relax mandatory rules just to return five products.

## 7. Explanation Agent

### Job

For every recommendation show:

- product name and SKU;
- price;
- rating;
- score;
- which preferences it matches;
- which written preference it may miss;
- why it ranks above the next product.

The output should be short enough for a merchandiser to use in a meeting.

## 8. Human Decision

A human should decide when:

- the scoring formula needs to change;
- two reasonable interpretations of a preference exist;
- a new persona field has no published scoring rule;
- an important ranking changes significantly;
- business risk is high.

The agent can find the problem and show evidence, but it should not invent business policy.

## Agentic loop

```text
PLAN
  ↓
ACT
  ↓
OBSERVE
  ↓
CRITIQUE
  ↓
TEST
  ↓
IMPROVE OR ESCALATE
  ↓
EXPLAIN
```

This loop is the main reason the solution is agentic: the system does not stop after the first answer. It observes and checks its own result.

## Audit information

For a production version we would store:

- persona ID;
- rule/formula version;
- products rejected;
- rejection reason;
- score components;
- official rank;
- sensitivity rank;
- missed preferences;
- final explanation;
- human approval when a rule changes.

This makes every recommendation reviewable later.
