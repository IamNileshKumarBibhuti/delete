// QuickTab Organizer — background worker. No external services or page scripts.
const KEY = "quicktabData";
const CAPTURE_MAX_AGE_MS = 10 * 60 * 1000;
let sequence = Promise.resolve();

function serial(task) {
  const current = sequence.then(task, task);
  sequence = current.catch(() => {});
  return current;
}

async function getData() {
  const record = await chrome.storage.local.get(KEY);
  const value = record[KEY];
  return {
    categories: Array.isArray(value?.categories) ? value.categories : [],
    capture: value?.capture || null,
    lastCategoryId: value?.lastCategoryId || null
  };
}
async function putData(data) { await chrome.storage.local.set({ [KEY]: data }); }
function safeUrl(tab) {
  const url = tab?.url || tab?.pendingUrl || "";
  return /^https?:\/\//i.test(url) ? url : null;
}
function saveIntoCategory(data, categoryId, tabs) {
  const cat = data.categories.find(c => c.id === categoryId);
  if (!cat) throw new Error("Category not found.");
  let added = 0;
  let already = 0;
  for (const tab of tabs) {
    const url = safeUrl(tab);
    if (!url) continue;
    const existing = cat.links.find(link => link.url === url);
    if (existing) {
      already++;
      if (tab.title && tab.title !== existing.title) existing.title = tab.title;
    } else {
      cat.links.push({url, title: (tab.title || url).slice(0, 250), addedAt: Date.now()});
      added++;
    }
  }
  data.lastCategoryId = categoryId;
  return {added, already};
}
async function getBrowserWindow() {
  const win = await chrome.windows.getLastFocused({windowTypes: ["normal"]});
  if (!win || typeof win.id !== "number") throw new Error("No Chrome window found.");
  return win.id;
}
async function activeTab(windowId) {
  const tabs = await chrome.tabs.query({active: true, windowId});
  if (!tabs.length) throw new Error("No active tab found.");
  return tabs[0];
}
async function addActive(categoryId, goNext = false) {
  const windowId = await getBrowserWindow();
  const tab = await activeTab(windowId);
  if (!safeUrl(tab)) throw new Error("Open a normal http:// or https:// website first.");
  const data = await getData();
  const result = saveIntoCategory(data, categoryId, [tab]);
  await putData(data);
  if (goNext) {
    const list = (await chrome.tabs.query({windowId})).sort((a, b) => a.index - b.index);
    const eligible = list.filter(t => safeUrl(t));
    const pos = eligible.findIndex(t => t.id === tab.id);
    if (eligible.length > 1 && pos !== -1) {
      await chrome.tabs.update(eligible[(pos + 1) % eligible.length].id, {active: true});
    }
  }
  return result;
}
async function openLinks(urls) {
  const windowId = await getBrowserWindow();
  const valid = urls.filter(url => typeof url === "string" && /^https?:\/\//i.test(url));
  for (const url of valid) {
    await chrome.tabs.create({windowId, url, active: false});
  }
  return valid.length;
}
async function doAction(msg) {
  const type = msg?.type;
  if (type === "getState") return {state: await getData()};
  if (type === "createCategory") {
    const name = String(msg.name || "").trim().slice(0, 65);
    if (!name) throw new Error("Enter a category name.");
    const data = await getData();
    const id = crypto.randomUUID();
    data.categories.push({id, name, links: []});
    data.lastCategoryId = id;
    await putData(data);
    return {state: data};
  }
  if (type === "renameCategory") {
    const data = await getData();
    const cat = data.categories.find(c => c.id === msg.id);
    if (!cat) throw new Error("Category not found.");
    const name = String(msg.name || "").trim().slice(0, 65);
    if (!name) throw new Error("Enter a category name.");
    cat.name = name;
    await putData(data);
    return {state: data};
  }
  if (type === "removeCategory") {
    const data = await getData();
    data.categories = data.categories.filter(c => c.id !== msg.id);
    if (data.capture?.categoryId === msg.id) data.capture = null;
    if (data.lastCategoryId === msg.id) data.lastCategoryId = null;
    await putData(data);
    return {state: data};
  }
  if (type === "saveCurrent" || type === "saveAndNext") {
    return {result: await addActive(msg.id, type === "saveAndNext")};
  }
  if (type === "saveHighlighted") {
    const windowId = await getBrowserWindow();
    const tabs = await chrome.tabs.query({highlighted: true, windowId});
    const data = await getData();
    const result = saveIntoCategory(data, msg.id, tabs);
    await putData(data);
    return {result};
  }
  if (type === "startCapture") {
    const windowId = await getBrowserWindow();
    const tab = await activeTab(windowId);
    const data = await getData();
    if (!data.categories.some(c => c.id === msg.id)) throw new Error("Category not found.");
    data.capture = {categoryId: msg.id, windowId, startedAt: Date.now()};
    if (safeUrl(tab)) saveIntoCategory(data, msg.id, [tab]);
    await putData(data);
    return {state: data};
  }
  if (type === "stopCapture") {
    const data = await getData();
    data.capture = null;
    await putData(data);
    return {state: data};
  }
  if (type === "openAll" || type === "openSelected") {
    const data = await getData();
    const cat = data.categories.find(c => c.id === msg.id);
    if (!cat) throw new Error("Category not found.");
    const requested = type === "openAll" ? cat.links.map(l => l.url) :
      cat.links.filter(l => Array.isArray(msg.urls) && msg.urls.includes(l.url)).map(l => l.url);
    return {opened: await openLinks(requested)};
  }
  if (type === "removeLink") {
    const data = await getData();
    const cat = data.categories.find(c => c.id === msg.id);
    if (!cat) throw new Error("Category not found.");
    cat.links = cat.links.filter(l => l.url !== msg.url);
    await putData(data);
    return {state: data};
  }
  if (type === "importData") {
    const raw = msg.data;
    if (!raw || !Array.isArray(raw.categories) || raw.categories.length > 150) throw new Error("Invalid QuickTab backup.");
    const safeCats = raw.categories.map(c => ({
      id: crypto.randomUUID(),
      name: String(c.name || "Imported").slice(0, 65),
      links: (Array.isArray(c.links) ? c.links : []).slice(0, 2000)
        .filter(l => typeof l?.url === "string" && /^https?:\/\//i.test(l.url))
        .map(l => ({url: l.url, title: String(l.title || l.url).slice(0, 250), addedAt: Date.now()}))
    }));
    const data = await getData();
    data.categories.push(...safeCats);
    await putData(data);
    return {state: data};
  }
  throw new Error("Unknown action.");
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  serial(() => doAction(message)).then(
    result => sendResponse({ok: true, ...result}),
    error => sendResponse({ok: false, error: error?.message || "Something went wrong."})
  );
  return true;
});

async function autoCaptureTab(tabId, windowId) {
  const data = await getData();
  const capture = data.capture;
  if (!capture || capture.windowId !== windowId) return;
  if (Date.now() - capture.startedAt > CAPTURE_MAX_AGE_MS) {
    data.capture = null;
    await putData(data);
    return;
  }
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab || !safeUrl(tab)) return;
  const result = saveIntoCategory(data, capture.categoryId, [tab]);
  if (result.added || result.already) await putData(data);
}
chrome.tabs.onActivated.addListener(info => {
  serial(() => autoCaptureTab(info.tabId, info.windowId)).catch(() => {});
});
chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
  if (change.url && tab.active) {
    serial(() => autoCaptureTab(tabId, tab.windowId)).catch(() => {});
  }
});
chrome.commands.onCommand.addListener(command => {
  if (command !== "save-to-last-category") return;
  serial(async () => {
    const data = await getData();
    if (data.lastCategoryId && data.categories.some(c => c.id === data.lastCategoryId)) {
      await addActive(data.lastCategoryId, false);
    }
  }).catch(() => {});
});

// Clicking the pinned toolbar icon opens the persistent side panel.
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({openPanelOnActionClick: true}).catch(() => {});
});
chrome.runtime.onStartup.addListener(() => {
  chrome.sidePanel.setPanelBehavior({openPanelOnActionClick: true}).catch(() => {});
});
chrome.sidePanel.setPanelBehavior({openPanelOnActionClick: true}).catch(() => {});
