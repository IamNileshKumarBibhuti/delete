# AGENTS.md — Northline Codex Sprint

## Team and scenario

- Team name: InfyAI Nexus
- Agent name: MarketGuide (`ProductAdvisorAgent`)
- Human owner: Prajjwal Sharma
- Scenario: **4 — Northline Market product advisor**

| # | Scenario | The problem |
|---|---|---|
| 4 | **Northline Market — product advisor** | The 1,000-SKU catalog needs a defensible top five for each frozen buyer persona, with hard requirements enforced before preferences affect rank. |

We taught MarketGuide one governing objective: maximize transparent fit to the written persona contract—not clicks, margin, inventory movement, or inferred taste, because those signals are absent. It autonomously turns validated local inputs into a versioned recommendation artifact and stops rather than inventing an unknown rule. This file records the operating instructions, corrections, and evidence behind that behavior.

### Autonomy contract

MarketGuide is authorized to perceive local inputs, construct persona-specific plans, execute hard filters and configured scoring, critique its own result, explain decisions, generate robustness samples, and persist evidence. It is not authorized to relax a hard rule, infer missing commercial facts, retune business weights, call a network service, publish to commerce, or approve its own output. This bounded autonomy is the central safety and Agentic AI design decision.

## Operating mode

Run from the repository root with Python 3.10+:

```powershell
python -m northline_market
python -m unittest discover -s tests -v
```

Default inputs are `data/product_catalog.csv`, `data/customer_personas.json`, and `config/agent_config.json`; outputs are `outputs/recommendations.json`, `outputs/report.md`, and `outputs/artifact_manifest.json`. `python -m northline_market --help` lists validation-only, profile comparison, config/path overrides, quiet mode, and fail-on-empty controls.

The agent executes this state machine:

1. **Ingest/validate:** `io.py` and `config.py` enforce exact schemas, unique IDs, UTF-8, finite bounded numbers, canonical tags, known rules, positive `k`, weights summing to one, valid versions, and known profile modes. It hashes all three inputs.
2. **Plan:** For each persona it records objective, category scope, hard rule codes, soft atoms, profile, configured weights, tie-break, `k`, and fallback. There is no free-form runtime prompt or hidden plan.
3. **Filter:** `policy.evaluate_hard` evaluates every product. All hard checks must pass. `required_tags` is a subset check; a blank numeric field is `None`, never zero.
4. **Score:** The default profile calculates `0.40 × price_fit + 0.30 × rating_norm + 0.30 × preference_fit`. The `published` profile uses only tag overlap for the last term; the `complete` profile averages all tag and numeric soft preferences.
5. **Rank:** Sort by score descending, rating descending, price ascending, SKU ascending. Retain `k+1` internally so the fifth displayed product is explained against the sixth.
6. **Verify/diagnose:** Reject duplicate ranked SKUs, hard failures, or unstable order; flag no/short lists, low preference fit, tight margins/cutoffs, and price dominance.
7. **Explain/emit:** Produce evidence, component scores, all hard checks, two-part explanations, primary/non-exclusive failure counts, plan, run health, versions/hashes, atomic JSON/Markdown, and a final hash manifest.

```text
CSV + JSON -> strict validator -> persona rule plan -> hard gate
    -> versioned scorer -> deterministic rank -> invariant guard
    -> evidence generator -> JSON audit + Markdown meeting report
```

Responsibilities stay separated: `io.py` owns trust boundaries, `config.py` validates policy, `policy.py` owns pure decisions, `agent.py` owns planning/orchestration/critique, `reporting.py` owns evidence persistence, `evaluation.py` owns profile diffs, `samples.py` owns synthetic robustness data, and `cli.py` owns user controls. The agent has no network tool, model key, commerce write action, or long-term mutable memory. Its durable state is the emitted artifact and stable hash-derived run ID.

### Agent responsibilities and collaboration

| Specialist stage | Responsibility | Evidence passed forward |
|---|---|---|
| Policy Reader | Validate catalog, persona, and agent configuration | Typed products/personas, versions, hashes |
| Planner | Convert each persona into an executable decision plan | Scope, rule codes, atoms, weights, tie-break, fallback |
| Constraint Guardian | Evaluate all hard requirements | Passed checks or exclusion reasons |
| Ranker | Apply the configured profile to eligible products | Component scores and deterministic order |
| Critic | Recheck invariants and commercial fragility | Hard-compliance proof and quality alerts |
| Explainer | Ground fit and next-item contrast in evidence | Two-part rationale per recommendation |
| Recorder | Persist human and machine artifacts | JSON, Markdown, hashes, commit manifest |

These are collaborating roles in one governed runtime, not seven independent chatbots. Structured hand-offs make generation, verification, and recording separable without creating multi-agent disagreement.

### Prompt, tools, and memory

There is no free-form runtime LLM prompt. We taught Codex to compile the goal into governed artifacts: `customer_personas.json` supplies the business contract, `agent_config.json` supplies the policy, schemas define permitted inputs, and pure functions define actions. This prompt-equivalent design prevents prompt drift and follows the brief's no-separate-model-API constraint.

MarketGuide uses only local tools: schema loaders, policy engine, scorer, critic, reporter, hasher, evaluator, and synthetic generator. Durable memory consists of source/config hashes, versions, explicit plans, checks, scores, alerts, and artifact hashes. In-process state is immutable or run-scoped; identical inputs produce the same run ID and order.

## Conventions we gave Codex

- The personas file is the contract. Hard requirements are gates, never negative score adjustments.
- Policy decisions are pure, typed, deterministic functions. Explanation text may only cite recorded product/rule/score evidence.
- Unknown keys fail validation. Missing values are surfaced. No brand, stock, compatibility, popularity, margin, or user intent is inferred from a name.
- Rules have stable codes (`H-CATEGORY`, `H-MAX-PRICE`, `H-MIN-BATTERY`, `H-MIN-RAM`, `H-MIN-RATING`, `H-MIN-INCHES`, `H-REQUIRED-TAGS`). Scores expose unrounded internal values and round only when serialized.
- Output order ends with SKU solely for deterministic exact ties. Atomic replacement prevents partial artifacts.
- `config/agent_config.json` is the only source for executable weights, normalization, versions, tie-breaks, and diagnostic thresholds; invalid or mismatched config stops the run.
- Quality alerts challenge the decision but cannot self-modify business policy. Merchandising approves any weight change.
- Standard library only; local files only; zero outbound calls. Generated output stays under `outputs/`; source data is read-only.
- CLI failures are concise and actionable with exit code 2. A valid but empty persona gets `no_eligible_products`; deployments can require `--fail-on-empty`.

The key convention change was from “tag overlap equals preference fit” to “all declared soft fields equal preference fit.” Before, weight, battery, and preferred rating disappeared from the calculation. After, each preferred tag and numeric condition leaves a named satisfaction value in JSON. We kept the old behavior as the `published` profile so the change is measurable and reversible.

In practical terms, Codex was instructed to answer every recommendation with four pieces of evidence: which hard rules passed, how each score component was calculated, why the product fits the persona, and why it beat the next eligible product. “Best product” without those four elements was treated as an incomplete result.

## How we decomposed the work

One Codex session played deliberately separate roles rather than deploying runtime sub-agents:

- **Analyst:** read the brief mirror, data dictionary, persona contract, catalog schema/distribution, and existing templates; identified the unused soft fields and missing operational data.
- **Policy designer:** preserved the published top-level weights, specified atomic preference curves, missing-value behavior, final tie stability, and no-candidate fallback.
- **Builder:** separated models, loaders, policy, orchestration, reporting, and CLI.
- **Adversarial verifier:** tested every rule type, missing values, unknown rules, duplicate SKUs, empty candidate sets, ties, artifact completeness, and end-to-end top results.
- **Merchandising reviewer:** compared complete and published profiles and inspected price dominance instead of treating a passing test as proof of business quality.
- **Operations reviewer:** added hashes, policy version, atomic writes, exit behavior, human approval, rollback, monitoring, and kill criteria.

A multi-agent runtime was rejected because the decision policy is small, deterministic, and contract-bound. Multiple judging agents would add disagreement and hidden reasoning without creating missing inventory or outcome data. Independent analysis/build/test roles were kept conceptually separate in one auditable implementation.

The later improvement loop reused those roles in three explicit cycles: correctness/configuration; autonomy/observability; and evaluation/synthetic robustness. Every cycle ended with regression tests and an end-to-end supplied-data run before the next assumption was challenged.

## What we forbade

- No product failing one hard field may be recommended, regardless of score.
- No silent rule relaxation, unknown-key ignore, missing-as-zero conversion, or category fallback.
- No network, API key, separate model call, package install, commerce write, add-to-cart, or storefront behavior.
- No invented stock, margin, sales, brand, compatibility, demographic, or customer-level data; no real Infosys/client data.
- No unapproved use of `review_count` as a ranking proxy. It is output evidence only.
- No mutation of `data/product_catalog.csv` or `data/customer_personas.json`.
- No claim that offline policy correctness proves conversion lift.
- No automatic production publish: merchandising owns the approval gate, and commerce availability must gate customer exposure.

## Where Codex got it wrong

The first end-to-end test fixture expected `SKU-0674` as `P-REMOTE`'s top result, but the implemented and independently printed ranking showed `SKU-0250`. The error was in the hand-written expected value; the test was corrected only after checking score evidence and the generated report. That is why expected fixtures should be generated from reviewed artifacts, not memory.

The first Markdown renderer also stored `why_fit` and `why_above_next` correctly in JSON but concatenated them without visible “Why” labels. A report-level test caught that the human artifact did not explicitly contain the requested framing. The renderer now prints two labelled bullets per SKU.

A later test run initially failed because Python's default temporary directory was outside the workspace sandbox. Test fixtures now reuse the fixed, ignored `tests/_runtime` workspace. The iterative audit also found that non-finite numbers could bypass validation, weights were duplicated between ranking and serialization, and “plan” was only a phase label. Configuration was centralized, `NaN`/infinity were rejected, plans became explicit, and regression tests were added. The final suite is 19/19 passing.

We also challenged a plausible-looking business result: `P-TRAVEL` ranks the $58.67 `SKU-0742` above `SKU-0011`, which fully meets weight plus both soft tags. The implementation is behaving as designed—the published 40% price weight overwhelms some preference value—but the result exposes an unresolved policy question. README flags this for merchandising rather than silently tuning weights.

## What the agent produced

MarketGuide v2 run `9a0ba3f8b0ac7804` processed 1,000 unique SKUs and five personas with no outbound calls:

| Persona | Eligible | Ranked SKUs (1 → 5) |
|---|---:|---|
| `P-STUDENT` | 16 | `SKU-0223`, `SKU-0229`, `SKU-0001`, `SKU-0465`, `SKU-0003` |
| `P-ITBUY` | 48 | `SKU-0223`, `SKU-0361`, `SKU-0794`, `SKU-0111`, `SKU-0124` |
| `P-TRAVEL` | 10 | `SKU-0742`, `SKU-0011`, `SKU-0073`, `SKU-0012`, `SKU-0013` |
| `P-DESIGN` | 49 | `SKU-0092`, `SKU-0741`, `SKU-0900`, `SKU-0916`, `SKU-0018` |
| `P-REMOTE` | 22 | `SKU-0250`, `SKU-0829`, `SKU-0869`, `SKU-0097`, `SKU-0021` |

All 25 emitted products pass every applicable hard rule. The complete/published comparison kept only nine of 25 products in the same rank position. Top-five membership changed by zero, one, one, two, and zero items respectively; `P-STUDENT` and `P-TRAVEL` changed top choice. This is evidence that the formula repair is material, not a documentation-only change.

### Expected impact

- **Customer decision surface:** 1,000 products become five defensible choices per persona—a 99.5% reduction.
- **Merchandising productivity:** meeting-ready evidence and generated profile diffs reduce manual review and rework; production must measure approval lead time.
- **Governance:** the prototype achieves 100% hard-rule compliance, while plans, alerts, hashes, and the manifest make every served list traceable.
- **Commercial outcome:** conversion or revenue lift is a future canary metric, guarded by availability, cancellation, and return rates; no offline uplift is claimed.

### Example agent decision trace

For `P-DESIGN`, the Planner selects monitor, ≥27 inches, rating ≥4.0, and price ≤$900 as hard rules, then expands IPS, color, and preferred rating ≥4.4 as soft atoms. The Guardian reduces 1,000 rows to 49 eligible products. The Ranker selects `SKU-0092` at 0.8760. The Critic confirms every hard check and finds an 0.0851 margin. The Explainer records that the runner-up lacks IPS. The Recorder binds that decision to run `9a0ba3f8b0ac7804` and the artifact manifest.

Artifacts:

- `outputs/recommendations.json`: machine/audit record with hashes, policy, checks, scores, explanations, and counts.
- `outputs/report.md`: compact merchandiser report.
- `outputs/artifact_manifest.json`: output hashes and commit marker.
- `outputs/comparison/`: both profiles plus generated JSON/Markdown ranking diff.
- `data/generated_product_samples.csv`: 150 deterministic synthetic robustness products.
- `data/generated_product_samples_manifest.json`: seed, provenance, scenario labels, and no-real-data declaration.
- `SOLUTION_PLAN.md`: pre-implementation plan.
- `docs/ARCHITECTURE.md` and `docs/IMPROVEMENT_LOG.md`: v2 design and iterative improvement evidence.
- `Northline_MarketGuide_Stakeholder_Deck.pptx` and `.pdf`: 18-slide editable/portable stakeholder deck with presenter notes.
- `tests/`: 19 policy, config, planning, diagnostic, evaluation, generation, fallback, output, and end-to-end tests.

Failure counts in the JSON are diagnostic and non-exclusive. A SKU may fail category, price, and rating simultaneously; excluded count is the authoritative row count.

## What we did not finish

The local batch agent, validation mode, quality diagnostics, reports, manifest, generated profile comparison, synthetic sample generator, and tests run. What remains intentionally unbuilt: storefront integration, live inventory/sellability, persona authoring/approval UI, scheduled execution, signed artifact registry, telemetry, A/B testing, and real conversion evaluation. The brief marks storefront, images, add-to-cart, and A/B test construction out of scope.

There are no labelled relevance judgments, so ranking quality is not proven beyond contract adherence and transparent formula behavior. `review_count` is not incorporated. The equal-atomic-preference model and retained 40% price weight need business sign-off. Input processing is in memory and is appropriate for 1,000 rows, not an unbounded production feed.

The supplied Markdown companion to the PDF was the machine-readable requirements source. `DS_Store` was treated as filesystem metadata, not scenario data.

### Future enhancement order

1. Obtain merchandising approval for component and atomic-preference weights using the generated profile diff and quality alerts.
2. Add live stock, sellability, and freshness as hard preconditions.
3. Add a signed approval registry, immutable artifact store, and scheduled/canary release path.
4. Define privacy-safe impression, click, purchase, cancellation, and return events.
5. Add category indexing and partitioned scoring only when measured volume or latency requires it.

## Failure modes and overrides

| Failure | Agent behavior | Human/operational override |
|---|---|---|
| Malformed CSV/JSON, duplicate ID, unknown rule | Stop before output; exit 2 | Data owner corrects input or ships reviewed rule support |
| Invalid/mismatched agent configuration or non-finite number | Stop before ranking; exit 2 | Policy owner fixes the versioned configuration/input |
| Missing field needed by hard minimum | Product fails that rule; evidence says missing | Merchandising fixes data; never waive silently |
| No eligible products | Emit explicit empty status; optional `--fail-on-empty` stops whole run | Merchandiser changes the contract/catalog or serves no recommendation |
| Fewer than five eligible | Emit only valid candidates | Human decides whether an undersized list is acceptable |
| Exact score/rating/price tie | SKU stabilizes order | Merchandiser may define a governed new tie-break |
| New catalog/persona hash | New stable run ID and reviewable diff | Approval gate decides publish/rollback |
| Stock or sellability absent/stale | Local prototype cannot detect it | Production availability gate suppresses item; stale feed turns serving off |
| Policy produces commercially odd but compliant result | Evidence exposes component cause | Merchandising approves weights; rollback to prior artifact/profile |
| Quality alert (tight margin, low fit, price dominance) | Preserve deterministic result but set review status | Merchandising reviews profile diff before approval |
| Artifact manifest missing/hash mismatch | Treat output pair as uncommitted | Re-run locally; do not publish partial artifacts |
| Any emitted hard violation or invariant failure | Fail closed; do not publish | Engineering incident plus policy/data review |
| Conversion/returns degrade after release | Not observable locally | Canary monitor pauses/rolls back using pre-agreed thresholds |

MarketGuide must never be the sole approver for persona policy, scoring-weight changes, customer exposure, or emergency constraint waivers. It fails first at missing business context—not arithmetic—and the correct override is a versioned human policy decision, never an improvised answer inside a run.

### Evaluation and success gates

| Gate | Prototype result | Production rule |
|---|---:|---|
| Hard compliance | 25/25; 100% | Zero tolerance; any violation stops publication |
| Persona coverage | 5/5 with five items | Alert/fail when an approved coverage threshold is missed |
| Determinism | Stable hashes and order | Same approved inputs/config must reproduce the artifact |
| Evidence completeness | Plan, checks, scores, explanations, alerts | 100% of served lists trace to a complete manifest |
| Robustness | 19 tests + 150 synthetic products | CI must pass before policy/catalog approval |
| Commercial outcome | Not measurable offline | Canary conversion/revenue lift with guarded return/cancellation rates |

The agent should be switched off—not “helpfully” degraded—on an unknown rule, invalid config, manifest mismatch, stale availability feed, emitted hard violation, or unexplained output mutation.
